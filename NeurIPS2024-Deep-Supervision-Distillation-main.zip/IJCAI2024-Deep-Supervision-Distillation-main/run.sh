python main.py --num_runs 1 --data  cifar10 --cl_type nc --agent DSD  --retrieve random --update random --mem_size 100

python main.py --num_runs 1 --data  cifar100 --cl_type nc --agent DSD  --retrieve random --update random --mem_size 500

python main.py --num_runs 1 --data  mini_imagenet --cl_type nc --agent DSD  --retrieve random --update random --mem_size 500

