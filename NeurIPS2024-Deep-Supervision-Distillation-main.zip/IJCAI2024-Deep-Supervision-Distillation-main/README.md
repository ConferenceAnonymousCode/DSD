# IJCAI2024-Deep-Supervision-Distillation
Source Code for anonymous IJCAI2024 submission, 'Learning from Intermediate Layers: Deep Supervision Distillation for Online Class-Incremental Continual Learning'.
